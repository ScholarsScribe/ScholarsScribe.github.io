
export default function HealthWellness() {
  const topics = [
    {
      title: "Mental Health",
      description: "Stress management, anxiety relief, and mindfulness practices",
      icon: "🧠",
      articles: ["Managing Academic Stress", "Meditation for Students", "Sleep Hygiene"]
    },
    {
      title: "Physical Fitness",
      description: "Exercise routines and nutrition tips for busy students",
      icon: "💪",
      articles: ["Dorm Room Workouts", "Healthy Eating on Budget", "Study Break Exercises"]
    },
    {
      title: "Work-Life Balance",
      description: "Finding harmony between studies, work, and personal life",
      icon: "⚖️",
      articles: ["Time Boundaries", "Digital Detox", "Social Connection"]
    },
    {
      title: "Preventive Care",
      description: "Healthcare resources and wellness checkups",
      icon: "🏥",
      articles: ["Campus Health Services", "Health Insurance Guide", "Preventive Screenings"]
    }
  ];

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Health & Wellness</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Prioritize your well-being with comprehensive health and wellness resources designed for students.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {topics.map((topic, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
            <div className="text-4xl mb-4">{topic.icon}</div>
            <h3 className="text-xl font-bold text-gray-800 mb-3">{topic.title}</h3>
            <p className="text-gray-600 mb-4">{topic.description}</p>
            <div className="space-y-2 mb-4">
              {topic.articles.map((article, articleIndex) => (
                <div key={articleIndex} className="text-blue-600 hover:text-blue-800 cursor-pointer text-sm">
                  → {article}
                </div>
              ))}
            </div>
            <button className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors">
              Explore Resources
            </button>
          </div>
        ))}
      </div>

      <div className="mt-16 bg-green-50 rounded-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Wellness Resources</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <div className="text-center">
            <h4 className="font-semibold text-gray-800 mb-2">Crisis Support</h4>
            <p className="text-gray-600 text-sm">24/7 mental health crisis hotline</p>
            <p className="text-blue-600 font-bold">988</p>
          </div>
          <div className="text-center">
            <h4 className="font-semibold text-gray-800 mb-2">Campus Counseling</h4>
            <p className="text-gray-600 text-sm">Free counseling services for students</p>
            <button className="text-blue-600 hover:text-blue-800 text-sm">Find Services</button>
          </div>
          <div className="text-center">
            <h4 className="font-semibold text-gray-800 mb-2">Wellness Apps</h4>
            <p className="text-gray-600 text-sm">Recommended apps for mental health</p>
            <button className="text-blue-600 hover:text-blue-800 text-sm">View List</button>
          </div>
        </div>
      </div>
    </div>
  );
}
