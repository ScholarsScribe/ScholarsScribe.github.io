
export default function Scholarships() {
  const scholarships = [
    {
      id: 1,
      title: "Merit-Based Academic Excellence Scholarship",
      amount: "$5,000",
      deadline: "March 15, 2024",
      eligibility: "GPA 3.5+, Undergraduate students",
      description: "Awarded to outstanding students demonstrating academic excellence and leadership potential."
    },
    {
      id: 2,
      title: "STEM Innovation Grant",
      amount: "$10,000",
      deadline: "April 1, 2024",
      eligibility: "STEM majors, Graduate students",
      description: "Supporting the next generation of innovators in science, technology, engineering, and mathematics."
    },
    {
      id: 3,
      title: "Community Service Leadership Award",
      amount: "$3,000",
      deadline: "February 28, 2024",
      eligibility: "Active community volunteers",
      description: "Recognizing students who make a positive impact in their communities through volunteer service."
    }
  ];

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Scholarship Opportunities</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Find financial aid opportunities to support your educational journey. New scholarships added regularly.
        </p>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {scholarships.map((scholarship) => (
          <div key={scholarship.id} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-4">
              <h2 className="text-2xl font-bold text-gray-800 mb-2 md:mb-0">
                {scholarship.title}
              </h2>
              <div className="text-right">
                <div className="text-2xl font-bold text-green-600">{scholarship.amount}</div>
                <div className="text-sm text-gray-500">Award Amount</div>
              </div>
            </div>
            
            <p className="text-gray-600 mb-4">{scholarship.description}</p>
            
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <h4 className="font-semibold text-gray-800 mb-1">Eligibility</h4>
                <p className="text-gray-600">{scholarship.eligibility}</p>
              </div>
              <div>
                <h4 className="font-semibold text-gray-800 mb-1">Application Deadline</h4>
                <p className="text-red-600 font-medium">{scholarship.deadline}</p>
              </div>
            </div>
            
            <div className="flex space-x-4">
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Apply Now
              </button>
              <button className="border border-blue-600 text-blue-600 px-6 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
