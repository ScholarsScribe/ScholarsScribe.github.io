
export default function PersonalDevelopment() {
  const categories = [
    {
      title: "Goal Setting & Planning",
      articles: ["SMART Goals Framework", "Vision Board Creation", "Time Management"],
      color: "bg-purple-500"
    },
    {
      title: "Mindset & Motivation",
      articles: ["Growth Mindset", "Overcoming Procrastination", "Building Confidence"],
      color: "bg-green-500"
    },
    {
      title: "Productivity & Habits",
      articles: ["Morning Routines", "Focus Techniques", "Habit Formation"],
      color: "bg-blue-500"
    },
    {
      title: "Communication Skills",
      articles: ["Public Speaking", "Active Listening", "Conflict Resolution"],
      color: "bg-yellow-500"
    }
  ];

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Personal Development</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Transform your mindset, build better habits, and unlock your full potential.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto mb-12">
        {categories.map((category, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg p-6">
            <div className={`w-12 h-12 ${category.color} rounded-lg mb-4 flex items-center justify-center`}>
              <span className="text-white font-bold text-lg">
                {category.title.charAt(0)}
              </span>
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-3">{category.title}</h3>
            <ul className="space-y-2">
              {category.articles.map((article, articleIndex) => (
                <li key={articleIndex} className="text-gray-600 hover:text-blue-600 cursor-pointer">
                  • {article}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="bg-gradient-to-r from-purple-500 to-blue-600 text-white rounded-lg p-8 text-center">
        <h2 className="text-2xl font-bold mb-4">30-Day Personal Growth Challenge</h2>
        <p className="mb-6">
          Join thousands of students in our structured program to build lasting positive habits.
        </p>
        <button className="bg-yellow-400 text-blue-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors">
          Join Challenge
        </button>
      </div>
    </div>
  );
}
