
export default function CodingCourses() {
  const courses = [
    {
      id: 1,
      title: "JavaScript Fundamentals for Beginners",
      level: "Beginner",
      duration: "6 weeks",
      price: "Free",
      description: "Learn the basics of JavaScript programming with hands-on projects and real-world examples.",
      skills: ["Variables & Functions", "DOM Manipulation", "Event Handling", "Basic Algorithms"]
    },
    {
      id: 2,
      title: "React Development Bootcamp",
      level: "Intermediate",
      duration: "12 weeks",
      price: "$299",
      description: "Master React.js and build modern web applications with hooks, routing, and state management.",
      skills: ["React Components", "State Management", "React Router", "API Integration"]
    },
    {
      id: 3,
      title: "Python for Data Science",
      level: "Intermediate",
      duration: "10 weeks",
      price: "$199",
      description: "Dive into data analysis and machine learning using Python, pandas, and scikit-learn.",
      skills: ["Data Analysis", "Pandas", "NumPy", "Machine Learning Basics"]
    }
  ];

  const levelColors = {
    Beginner: "bg-green-100 text-green-800",
    Intermediate: "bg-yellow-100 text-yellow-800",
    Advanced: "bg-red-100 text-red-800"
  };

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Coding Courses</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Level up your programming skills with our curated selection of coding courses. 
          From beginner to advanced, we have something for everyone.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {courses.map((course) => (
          <div key={course.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${levelColors[course.level]}`}>
                  {course.level}
                </span>
                <span className="text-2xl font-bold text-blue-600">{course.price}</span>
              </div>
              
              <h2 className="text-xl font-bold text-gray-800 mb-3">
                {course.title}
              </h2>
              
              <p className="text-gray-600 mb-4">{course.description}</p>
              
              <div className="mb-4">
                <h4 className="font-semibold text-gray-800 mb-2">What you'll learn:</h4>
                <ul className="space-y-1">
                  {course.skills.map((skill, index) => (
                    <li key={index} className="text-gray-600 text-sm flex items-center">
                      <svg className="w-4 h-4 text-green-500 mr-2" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                      </svg>
                      {skill}
                    </li>
                  ))}
                </ul>
              </div>
              
              <div className="flex items-center justify-between mb-4 text-sm text-gray-500">
                <span>Duration: {course.duration}</span>
              </div>
              
              <button className="w-full bg-blue-600 text-white py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Enroll Now
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
