
export default function JobBoard() {
  const jobs = [
    {
      id: 1,
      title: "Frontend Developer Intern",
      company: "TechStart Inc.",
      location: "Remote",
      type: "Internship",
      salary: "$20-25/hour",
      posted: "2 days ago",
      description: "Join our dynamic team as a frontend developer intern and gain hands-on experience with React, TypeScript, and modern web technologies."
    },
    {
      id: 2,
      title: "Data Analyst",
      company: "Analytics Pro",
      location: "New York, NY",
      type: "Full-time",
      salary: "$65,000-$75,000",
      posted: "1 week ago",
      description: "Seeking a detail-oriented data analyst to help drive business decisions through data insights and visualization."
    },
    {
      id: 3,
      title: "Content Marketing Specialist",
      company: "Growth Media",
      location: "San Francisco, CA",
      type: "Full-time",
      salary: "$55,000-$65,000",
      posted: "3 days ago",
      description: "Create compelling content strategies and manage social media campaigns for our diverse client portfolio."
    }
  ];

  const typeColors = {
    "Internship": "bg-blue-100 text-blue-800",
    "Full-time": "bg-green-100 text-green-800",
    "Part-time": "bg-yellow-100 text-yellow-800",
    "Contract": "bg-purple-100 text-purple-800"
  };

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Job Board</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Discover exciting career opportunities from companies that value talent and growth. 
          Find your next opportunity here.
        </p>
      </div>

      <div className="max-w-4xl mx-auto space-y-6">
        {jobs.map((job) => (
          <div key={job.id} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
            <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
              <div className="flex-1">
                <h2 className="text-2xl font-bold text-gray-800 mb-2">{job.title}</h2>
                <div className="flex flex-wrap items-center gap-4 mb-3">
                  <span className="text-lg font-semibold text-blue-600">{job.company}</span>
                  <span className="text-gray-600">{job.location}</span>
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${typeColors[job.type]}`}>
                    {job.type}
                  </span>
                </div>
              </div>
              <div className="text-right mt-4 md:mt-0">
                <div className="text-xl font-bold text-green-600">{job.salary}</div>
                <div className="text-sm text-gray-500">Posted {job.posted}</div>
              </div>
            </div>
            
            <p className="text-gray-600 mb-4">{job.description}</p>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <button className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                Apply Now
              </button>
              <button className="border border-blue-600 text-blue-600 px-6 py-2 rounded-lg hover:bg-blue-50 transition-colors">
                Save Job
              </button>
              <button className="border border-gray-300 text-gray-600 px-6 py-2 rounded-lg hover:bg-gray-50 transition-colors">
                Share
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="text-center mt-12">
        <button className="bg-yellow-400 text-blue-900 px-8 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors">
          Load More Jobs
        </button>
      </div>
    </div>
  );
}
