
import Link from 'next/link';

export default function BlogPosts() {
  const posts = [
    {
      id: 1,
      title: "10 Essential Study Tips for Academic Success",
      excerpt: "Master these proven study techniques to boost your grades and retention.",
      category: "Education",
      date: "2024-01-15",
      readTime: "5 min read"
    },
    {
      id: 2,
      title: "How to Write a Winning Scholarship Essay",
      excerpt: "Stand out from the competition with these essay writing strategies.",
      category: "Scholarships",
      date: "2024-01-12",
      readTime: "8 min read"
    },
    {
      id: 3,
      title: "Building Your First Portfolio Website",
      excerpt: "Step-by-step guide to creating a professional online presence.",
      category: "Technology",
      date: "2024-01-10",
      readTime: "12 min read"
    }
  ];

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Blog Posts</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Discover insights, tips, and strategies to accelerate your academic and professional journey.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
        {posts.map((post) => (
          <article key={post.id} className="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
            <div className="p-6">
              <div className="flex items-center mb-4">
                <span className="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-sm font-medium">
                  {post.category}
                </span>
                <span className="text-gray-500 text-sm ml-auto">{post.readTime}</span>
              </div>
              
              <h2 className="text-xl font-bold text-gray-800 mb-3 hover:text-blue-600">
                <Link href={`/blog-posts/${post.id}`}>
                  {post.title}
                </Link>
              </h2>
              
              <p className="text-gray-600 mb-4 line-clamp-3">
                {post.excerpt}
              </p>
              
              <div className="flex items-center justify-between">
                <span className="text-gray-500 text-sm">{post.date}</span>
                <Link 
                  href={`/blog-posts/${post.id}`}
                  className="text-blue-600 hover:text-blue-800 font-medium text-sm"
                >
                  Read More →
                </Link>
              </div>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}
