
export default function CareerAdvancement() {
  const resources = [
    {
      title: "Resume Building Masterclass",
      type: "Course",
      duration: "2 hours",
      description: "Learn to craft compelling resumes that get noticed by employers."
    },
    {
      title: "Interview Preparation Guide",
      type: "Guide",
      duration: "45 min read",
      description: "Master the art of interviewing with proven strategies and practice questions."
    },
    {
      title: "LinkedIn Optimization",
      type: "Workshop",
      duration: "1.5 hours",
      description: "Optimize your LinkedIn profile to attract recruiters and build your network."
    },
    {
      title: "Salary Negotiation Tactics",
      type: "Webinar",
      duration: "1 hour",
      description: "Learn effective strategies to negotiate competitive compensation packages."
    }
  ];

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">Career Advancement</h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Accelerate your professional growth with expert-curated resources and strategies.
        </p>
      </div>

      <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
        {resources.map((resource, index) => (
          <div key={index} className="bg-white rounded-lg shadow-lg p-6 hover:shadow-xl transition-shadow">
            <div className="flex items-center justify-between mb-3">
              <span className="px-3 py-1 bg-blue-100 text-blue-800 text-sm font-medium rounded-full">
                {resource.type}
              </span>
              <span className="text-gray-500 text-sm">{resource.duration}</span>
            </div>
            <h3 className="text-xl font-bold text-gray-800 mb-3">{resource.title}</h3>
            <p className="text-gray-600 mb-4">{resource.description}</p>
            <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
              Access Resource
            </button>
          </div>
        ))}
      </div>

      <div className="mt-16 bg-gradient-to-r from-blue-50 to-yellow-50 rounded-lg p-8">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Career Assessment Tool</h2>
        <p className="text-gray-600 mb-6">
          Take our comprehensive career assessment to identify your strengths and discover new opportunities.
        </p>
        <button className="bg-yellow-400 text-blue-900 px-6 py-3 rounded-lg font-semibold hover:bg-yellow-300 transition-colors">
          Start Assessment
        </button>
      </div>
    </div>
  );
}
